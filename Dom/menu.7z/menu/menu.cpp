#include "display.h"

#include "globals.h"
#include "menu.h"
#include "keyboard.h"
#include "messages.h"

extern "C" {

typedef const struct PROGMEM{
	void       *Next;
	void       *Previous;
	void       *Parent;
	void       *Child;
	uint8_t     Select;
	const char  Text[10];
} menuItem;

menuItem* selectedMenuItem; // текущий пункт меню

//menuItem* menuStack[10];
volatile uint8_t menuStackTop;


#define MAKE_MENU(Name, Next, Previous, Parent, Child, Select, Text) \
    extern menuItem Next;     \
	extern menuItem Previous; \
	extern menuItem Parent;   \
	extern menuItem Child;  \
	menuItem const Name = {(void*)&Next, (void*)&Previous, (void*)&Parent, (void*)&Child, (uint8_t)Select, { Text }}

#define PREVIOUS   ((menuItem*)pgm_read_word(&selectedMenuItem->Previous))
#define NEXT       ((menuItem*)pgm_read_word(&selectedMenuItem->Next))
#define PARENT     ((menuItem*)pgm_read_word(&selectedMenuItem->Parent))
#define CHILD      ((menuItem*)pgm_read_word(&selectedMenuItem->Child))
#define SELECT		(pgm_read_byte(&selectedMenuItem->Select))

const char strNULL[] PROGMEM = "";

#define NULL_ENTRY Null_Menu

/*
menuItem        Null_Menu = {(void*)0, (void*)0, (void*)0, (void*)0, 0, {0x00}};
//                 NEXT,      PREVIOUS     PARENT,     CHILD
MAKE_MENU(m_s1i1,  m_s1i2,    NULL_ENTRY,  NULL_ENTRY, m_s2i1,       0, "Start");
MAKE_MENU(m_s1i2,  m_s1i3,    m_s1i1,      NULL_ENTRY, m_s3i1,       0, "Settings");
MAKE_MENU(m_s1i3,  NULL_ENTRY,m_s1i2,      NULL_ENTRY, NULL_ENTRY,   MENU_RESET, "Reset");

// ������� ������
MAKE_MENU(m_s2i1,  m_s2i2,    NULL_ENTRY,  m_s1i1,     NULL_ENTRY,   MENU_MODE1, "Mode 1");
MAKE_MENU(m_s2i2,  m_s2i3,    m_s2i1,      m_s1i1,     NULL_ENTRY,   MENU_MODE2, "Mode 2");
MAKE_MENU(m_s2i3,  NULL_ENTRY,m_s2i2,      m_s1i1,     NULL_ENTRY,   MENU_MODE3, "Mode 3");

// ������� ���������
MAKE_MENU(m_s3i1,  m_s3i2,    NULL_ENTRY,  m_s1i2,     m_s4i1,       0, "Pressure");
MAKE_MENU(m_s3i2,  NULL_ENTRY,m_s3i1,      m_s1i2,     m_s5i1,       0, "Time");

// ������� ��������
MAKE_MENU(m_s4i1,  m_s4i2,    NULL_ENTRY,  m_s3i1,     NULL_ENTRY,   MENU_SENS1, "Sensor 1");
MAKE_MENU(m_s4i2,  NULL_ENTRY,m_s4i1,      m_s3i1,     NULL_ENTRY,   MENU_SENS2, "Sensor 2");

// ������� �����
MAKE_MENU(m_s5i1,  m_s5i2,    NULL_ENTRY,  m_s3i2,     NULL_ENTRY,   MENU_WARM, "Warm");
MAKE_MENU(m_s5i2,  NULL_ENTRY,m_s5i1,      m_s3i2,     NULL_ENTRY,   MENU_PROCESS, "Process");
*/

menuItem Null_Menu = {(void*)0, (void*)0, (void*)0, (void*)0, 0, {0x00}};

//                 NEXT,      PREVIOUS     PARENT,     CHILD
MAKE_MENU(m_s1i1,  m_s1i2,    NULL_ENTRY,  NULL_ENTRY, m_s2i1,       0, "Light");
MAKE_MENU(m_s1i2,  m_s1i3,    m_s1i1,      NULL_ENTRY, m_s3i1,       0, "Door");
MAKE_MENU(m_s1i3,  m_s1i4,    m_s1i2,      NULL_ENTRY, m_s4i1,       0, "Call");
MAKE_MENU(m_s1i4,  NULL_ENTRY, m_s1i3,      NULL_ENTRY, m_s5i1,       0, "Temp");


// �������  �����
MAKE_MENU(m_s2i1,  m_s2i2,    NULL_ENTRY,  m_s1i1,      NULL_ENTRY,   MENU_LightMode1, "10%");
MAKE_MENU(m_s2i2,  m_s2i3,    m_s2i1,      m_s1i1,      NULL_ENTRY,   MENU_LightMode2, "20%");
MAKE_MENU(m_s2i3,  m_s2i4,    m_s2i2,      m_s1i1,     NULL_ENTRY,   MENU_LightMode3, "30%");
MAKE_MENU(m_s2i4,  m_s2i5,    m_s2i3,      m_s1i1,     NULL_ENTRY,   MENU_LightMode4, "40%");
MAKE_MENU(m_s2i5,  m_s2i6,    m_s2i4,       m_s1i1,     NULL_ENTRY,   MENU_LightMode5, "50%");
MAKE_MENU(m_s2i6,  m_s2i7,    m_s2i5,       m_s1i1,     NULL_ENTRY,   MENU_LightMode6, "60%");
MAKE_MENU(m_s2i7,  m_s2i8,    m_s2i6,     m_s1i1,      NULL_ENTRY,   MENU_LightMode7, "70%");
MAKE_MENU(m_s2i8,  m_s2i9,    m_s2i7,       m_s1i1,     NULL_ENTRY,   MENU_LightMode8, "80%");
MAKE_MENU(m_s2i9,  m_s2i10,   m_s2i8,      m_s1i1,     NULL_ENTRY,   MENU_LightMode9, "90%");
MAKE_MENU(m_s2i10,  m_s2i11,   m_s2i9,      m_s1i1,     NULL_ENTRY,   MENU_LightMode10, "100%");
MAKE_MENU(m_s2i11,  NULL_ENTRY,m_s2i10,      m_s1i1,     NULL_ENTRY,   MENU_LightMode0, "OFF");


// ������� �����
MAKE_MENU(m_s3i1,   m_s3i1,    NULL_ENTRY,      m_s1i2,     NULL_ENTRY,   MENU_DOOR1, "Open");
MAKE_MENU(m_s3i2,  m_s3i2,     m_s3i2,          m_s1i2,     NULL_ENTRY,   MENU_DOOR2, "+ Key");
MAKE_MENU(m_s3i3,  m_s3i3,     m_s3i3,          m_s1i2,     NULL_ENTRY,   MENU_DOOR2, "- Key");
MAKE_MENU(m_s3i4,  NULL_ENTRY, m_s3i4,          m_s1i2,     NULL_ENTRY,   MENU_DOOR0, "OFF");

// ������� ������
MAKE_MENU(m_s4i1,  m_s4i2,    NULL_ENTRY, m_s1i3,     NULL_ENTRY,   MENU_CALLMODE1, "Loud");
MAKE_MENU(m_s4i2,  m_s4i3,    m_s4i1,      m_s1i3,     NULL_ENTRY,   MENU_CALLMODE2, "Low");
MAKE_MENU(m_s4i3,  NULL_ENTRY,m_s4i2,      m_s1i3,     NULL_ENTRY,   MENU_CALLMODE0, "Block");


// �������  ����������� 
MAKE_MENU(m_s5i1,  m_s5i2,    NULL_ENTRY,  m_s1i4,     NULL_ENTRY,   MENU_TempMode15, "15\x01");
MAKE_MENU(m_s5i2,  m_s5i3,    m_s5i1,      m_s1i4,     NULL_ENTRY,   MENU_TempMode16, "16");
MAKE_MENU(m_s5i3,  m_s5i4,    m_s5i2,      m_s1i4,     NULL_ENTRY,   MENU_TempMode17, "17");
MAKE_MENU(m_s5i4,  m_s5i5,    m_s5i3,      m_s1i4,     NULL_ENTRY,   MENU_TempMode18, "18");
MAKE_MENU(m_s5i5,  m_s5i6,    m_s5i4,      m_s1i4,    NULL_ENTRY,   MENU_TempMode19, "19");
MAKE_MENU(m_s5i6,  m_s5i7,    m_s5i5,      m_s1i4,      NULL_ENTRY,   MENU_TempMode20, "20");
MAKE_MENU(m_s5i7,  m_s5i8,    m_s5i6,      m_s1i4,      NULL_ENTRY,   MENU_TempMode21, "21");
MAKE_MENU(m_s5i8,  m_s5i9,    m_s5i7,      m_s1i4,      NULL_ENTRY,   MENU_TempMode22, "22");
MAKE_MENU(m_s5i9,  m_s5i10,    m_s5i8,     m_s1i4,      NULL_ENTRY,    MENU_TempMode23,"23");
MAKE_MENU(m_s5i10,  m_s5i11,   m_s5i9,     m_s1i4,     NULL_ENTRY,   MENU_TempMode24, "24");
MAKE_MENU(m_s5i11,  m_s5i12,   m_s5i10,    m_s1i4,  NULL_ENTRY,   MENU_TempMode25, "25");
MAKE_MENU(m_s5i12,  m_s5i13,   m_s5i11,    m_s1i4,     NULL_ENTRY,   MENU_TempMode26, "26");
MAKE_MENU(m_s5i13,  m_s5i14,   m_s5i12,    m_s1i4,    NULL_ENTRY,   MENU_TempMode27, "27");
MAKE_MENU(m_s5i14,  m_s5i15,   m_s5i13,    m_s1i4,     NULL_ENTRY,   MENU_TempMode28, "28");
MAKE_MENU(m_s5i15,  m_s5i16,   m_s5i14,    m_s1i4,    NULL_ENTRY,   MENU_TempMode29, "29");
MAKE_MENU(m_s5i16,  m_s5i17,   m_s5i15,    m_s1i4,    NULL_ENTRY,   MENU_TempMode30, "30");
MAKE_MENU(m_s5i17,  NULL_ENTRY,m_s5i16,    m_s1i4,    NULL_ENTRY,   MENU_TempMode0, "OFF");


void menuChange(menuItem* NewMenu)
{
	if ((void*)NewMenu == (void*)&NULL_ENTRY)
	  return;

	selectedMenuItem = NewMenu;
}

unsigned char dispMenu(msg_par par) {
	menuItem* tempMenu;

	lcd.clear();
	// ������ ������ - ���������. ��� ����� ���� �������� ������
	lcd.setCursor(1,0);
	tempMenu = (menuItem*)pgm_read_word(&selectedMenuItem->Parent);
	if ((void*)tempMenu == (void*)&NULL_ENTRY) { // �� �� ������� ������
		lcd.print(PSTR("MENU:"));
	} else {
		lcd.print((char *)tempMenu->Text);
	}

	// ������ ������ - ������� ����� ����
	lcd.setCursor (1,1);
	lcd.print((char *)selectedMenuItem->Text);

	return (1);
}

uint8_t menuKey(msg_par par) {
	switch (par) {
	case 0: {
		return 1;
	}
	case KEY_LEFT: {
		menuChange(PREVIOUS);
		break;
	}
	case KEY_DOWN: {
		menuChange(NEXT);
		break;
	}
	case KEY_RIGHT:
		;
	case KEY_OK:
		{ // ����� ������
			uint8_t sel;
			sel = SELECT;
			if (sel != 0) {
				sendMessage(MSG_MENU_SELECT, sel);

				killHandler(MSG_KEY_PRESS, &menuKey);
				killHandler(MSG_DISP_REFRESH, &dispMenu);

				return (1);
			} else {
				menuChange(CHILD);
			}
			break;
		}
	case KEY_UP: { // ������ ������ (�������)
		menuChange(PARENT);
	}
	}
	dispMenu(0);
	return (1);
}

uint8_t startMenu() {
	selectedMenuItem = (menuItem*)&m_s1i1;

	dispMenu(0);
	setHandler(MSG_KEY_PRESS, &menuKey);
	setHandler(MSG_DISP_REFRESH, &dispMenu);
	return (0);
}

void initMenu() {
	//lcd_init();
}
}

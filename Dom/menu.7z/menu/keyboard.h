#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

#define KEY_UP				1
#define KEY_DOWN			2
#define KEY_RIGHT			3
#define KEY_LEFT			4
#define KEY_OK				5

extern "C" void  KBD_init();

#endif

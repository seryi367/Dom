#include "Buttons.h"

#include "globals.h"
#include "keyboard.h"
#include "messages.h"

extern "C" {
uint8_t lastKey,prevKey;
uint8_t kf1,kf2,kf3;

unsigned char getKeyCode() {
	if (joyClick()) {
		return KEY_OK;
	}
	if (joyUp()) {
		return KEY_UP;
	}
	if (joyDown()) {
		return KEY_DOWN;
	}
	if (joyLeft()) {
		return KEY_LEFT;
	}
	if (joyRight()) {
		return KEY_RIGHT;
	}
	return 0;
}

unsigned char readKey(msg_par par) {
	kf3=kf2;
	kf2=kf1;
	kf1=getKeyCode();
	
	if ((kf2==kf1) && (kf3==kf2)) {
		prevKey = lastKey;
		lastKey = kf1;
	
		if (prevKey != lastKey) {
			sendMessage(MSG_KEY_PRESS, lastKey);
			killTimer(MSG_KEY_REPEAT);
			if (lastKey) {
				//setTimer(MSG_KEY_REPEAT,40,50);
			}
		}
	}
	return(0);
}

unsigned char repeatKey(msg_par par) {
	if (prevKey == lastKey) {
		sendMessage(MSG_KEY_PRESS, lastKey);
		if (par>5)
			setTimer(MSG_KEY_REPEAT,par-1,par);
		else
			setTimer(MSG_KEY_REPEAT,5,5);
	}
	return(0);
}



void  KBD_init() {
	
	lastKey = 0;
	prevKey = 0;

	setHandler(MSG_KEY_SCAN, &readKey);
	setHandler(MSG_KEY_REPEAT, &repeatKey);

	setTimer(MSG_KEY_SCAN, 1, 1);
}
}

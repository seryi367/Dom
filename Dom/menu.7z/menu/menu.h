#ifndef _MENU_H_
#define _MENU_H_

enum {
    MENU_CANCEL=1,
    MENU_LightMode1,
    MENU_LightMode2,
    MENU_LightMode3,
    MENU_LightMode4,
    MENU_LightMode5,
    MENU_LightMode6,
    MENU_LightMode7,
    MENU_LightMode8,
    MENU_LightMode9,
    MENU_LightMode10,
    MENU_LightMode0,
    
    MENU_DOOR1,
    MENU_DOOR2,
    MENU_DOOR3,
    MENU_DOOR0,
    
    MENU_CALLMODE1,
    MENU_CALLMODE2,
    MENU_CALLMODE0,
    
    MENU_TempMode15,
    MENU_TempMode16,
    MENU_TempMode17,
    MENU_TempMode18,
    MENU_TempMode19,
    MENU_TempMode20,
    MENU_TempMode21,
    MENU_TempMode22,
    MENU_TempMode23,
    MENU_TempMode24,
    MENU_TempMode25,
    MENU_TempMode26,
    MENU_TempMode27,
    MENU_TempMode28,
    MENU_TempMode29,
    MENU_TempMode30,
    MENU_TempMode0,
    
    
};

extern "C" uint8_t startMenu();
extern "C" void initMenu();

#endif
